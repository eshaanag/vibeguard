res.json(process.env)
